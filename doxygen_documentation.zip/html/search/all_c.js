var searchData=
[
  ['unleash',['unleash',['../class_game_board.html#ace2ffdca5741139a896b502853faff27',1,'GameBoard']]],
  ['updateattacks',['updateAttacks',['../class_game_board.html#a452480b0daf8eb0caa799404fbd3128f',1,'GameBoard']]],
  ['updatefalcon',['updateFalcon',['../class_game_board.html#a5c46ed85fc09ea1153af6e8de777a1e1',1,'GameBoard']]],
  ['updateobjects',['updateObjects',['../class_game_board.html#a8ced9fa8a639798165ad6cb6bcbd0dac',1,'GameBoard']]]
];
