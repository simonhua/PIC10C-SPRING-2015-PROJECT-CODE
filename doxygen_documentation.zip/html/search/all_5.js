var searchData=
[
  ['instructions',['instructions',['../class_main_window.html#aeeabb8c67fc108c9df2b0da0d9674181',1,'MainWindow']]]
];
