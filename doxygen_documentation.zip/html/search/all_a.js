var searchData=
[
  ['showevent',['showEvent',['../class_game_board.html#a8cf0f1726da9d4fdfe9d044d290aca9d',1,'GameBoard']]],
  ['story',['story',['../class_main_window.html#a36f43f1230eecbee642b719580fa96a7',1,'MainWindow']]]
];
