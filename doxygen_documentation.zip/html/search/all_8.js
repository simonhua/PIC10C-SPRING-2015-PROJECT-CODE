var searchData=
[
  ['new_5fgame',['new_game',['../class_main_window.html#ae01676d83517b79caacdd8a22d6bb94e',1,'MainWindow']]]
];
