var searchData=
[
  ['_7egameboard',['~GameBoard',['../class_game_board.html#a48e19b4953c87cc5eea1f9152d09499e',1,'GameBoard']]],
  ['_7emainwindow',['~MainWindow',['../class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]]
];
